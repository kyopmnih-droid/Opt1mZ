package com.cok.optimasihp

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.concurrent.locks.LockSupport
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MacroService : Service() {

    companion object {
        @Volatile
        var running = false

        @Volatile
        var editMode = true
    }

    private class MaxHeightScroll(ctx: Context, val maxH: () -> Int) : ScrollView(ctx) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(
                widthMeasureSpec,
                View.MeasureSpec.makeMeasureSpec(maxH(), View.MeasureSpec.AT_MOST)
            )
        }
    }

    private class ParticleView(ctx: Context) : View(ctx) {
        private val dens = ctx.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rnd = java.util.Random()
        private val n = 26
        private val xs = FloatArray(n)
        private val ys = FloatArray(n)
        private val vx = FloatArray(n)
        private val vy = FloatArray(n)
        private var last = 0L
        private var bg: Shader? = null
        private var glowA: Shader? = null
        private var glowB: Shader? = null

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            val fw = w.toFloat()
            val fh = h.toFloat()
            bg = LinearGradient(0f, 0f, 0f, fh, Color.rgb(22, 24, 48), Color.rgb(9, 10, 20), Shader.TileMode.CLAMP)
            glowA = RadialGradient(fw * 0.9f, fh * 0.05f, fw * 0.8f, Color.argb(90, 139, 123, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            glowB = RadialGradient(fw * 0.05f, fh * 0.95f, fw * 0.7f, Color.argb(70, 62, 224, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            for (i in 0 until n) {
                xs[i] = rnd.nextFloat() * fw
                ys[i] = rnd.nextFloat() * fh
                vx[i] = (rnd.nextFloat() - 0.5f) * 26f * dens
                vy[i] = (rnd.nextFloat() - 0.5f) * 26f * dens
            }
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            paint.style = Paint.Style.FILL
            paint.shader = bg
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = glowA
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = glowB
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null

            val now = System.nanoTime()
            val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
            last = now
            for (i in 0 until n) {
                xs[i] += vx[i] * dt
                ys[i] += vy[i] * dt
                if (xs[i] < 0f || xs[i] > w) vx[i] = -vx[i]
                if (ys[i] < 0f || ys[i] > h) vy[i] = -vy[i]
            }
            val link = 85f * dens
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dens
            for (i in 0 until n) {
                for (j in i + 1 until n) {
                    val dx = xs[i] - xs[j]
                    val dy = ys[i] - ys[j]
                    val d = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (d < link) {
                        val a = ((1f - d / link) * 120).toInt()
                        paint.color = if (i % 2 == 0) Color.argb(a, 139, 123, 255) else Color.argb(a, 62, 224, 255)
                        c.drawLine(xs[i], ys[i], xs[j], ys[j], paint)
                    }
                }
            }
            paint.style = Paint.Style.FILL
            for (i in 0 until n) {
                paint.color = if (i % 2 == 0) Color.argb(230, 170, 155, 255) else Color.argb(230, 120, 235, 255)
                c.drawCircle(xs[i], ys[i], 1.8f * dens, paint)
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dens
            paint.color = Color.argb(60, 255, 255, 255)
            c.drawRoundRect(dens, dens, w - dens, h - dens, 24f * dens, 24f * dens, paint)
            postInvalidateOnAnimation()
        }

        override fun onDetachedFromWindow() {
            last = 0L
            super.onDetachedFromWindow()
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null

    private var target: TextView? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var trigger: TextView? = null
    private var triggerLp: WindowManager.LayoutParams? = null

    private var panelBox: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelShown = false
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bubbleShown = false

    private var statusTv: TextView? = null
    private var tvIv: TextView? = null
    private var tvGap: TextView? = null
    private var skIv: SeekBar? = null
    private var skGap: SeekBar? = null
    private var btnRep: TextView? = null
    private var btnDbl: TextView? = null

    @Volatile
    private var pressed = false
    private var firing = false

    private val accent = Color.rgb(139, 123, 255)

    private fun prefs() = getSharedPreferences("macro", Context.MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun iv(): Int = prefs().getInt("interval", 30).coerceIn(1, 500)
    private fun gp(): Int = prefs().getInt("gap", 40).coerceIn(1, 500)
    private fun mode(): String = prefs().getString("mode", "repeat") ?: "repeat"
    private fun tapPx() = dp(prefs().getInt("tapSize", 56).coerceIn(30, 120))
    private fun tgPx() = dp(prefs().getInt("tgSize", 44).coerceIn(24, 100))
    private fun trans() = prefs().getInt("trans", 30).coerceIn(0, 85)

    private fun msFromP(p: Int): Int = 500.0.pow(p / 100.0).roundToInt().coerceIn(1, 500)
    private fun pFromMs(ms: Int): Int = (ln(ms.toDouble()) / ln(500.0) * 100).roundToInt().coerceIn(0, 100)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Turbo.compat = prefs().getBoolean("compat", false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (target == null) showOverlay()
        running = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hideOverlay()
        running = false
        super.onDestroy()
    }

    private fun startFg() {
        val ch = "macro"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Makro", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Makro aktif")
            .setContentText("Tombol makro tampil di layar")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        wm?.defaultDisplay?.getRealMetrics(dm)
        return dm
    }

    @Suppress("DEPRECATION")
    private fun rawPoint(): Pair<Int, Int>? {
        val t = target ?: return null
        val d = Turbo.dev ?: return null
        val w = wm ?: return null
        val loc = IntArray(2)
        t.getLocationOnScreen(loc)
        val cx = loc[0] + t.width / 2f
        val cy = loc[1] + t.height / 2f
        val dm = metrics()
        val nx = cx / dm.widthPixels
        val ny = cy / dm.heightPixels
        val p = when (w.defaultDisplay.rotation) {
            1 -> Pair(ny, 1f - nx)
            2 -> Pair(1f - nx, 1f - ny)
            3 -> Pair(1f - ny, nx)
            else -> Pair(nx, ny)
        }
        return Pair(
            (p.first * d.maxX).toInt().coerceIn(0, d.maxX),
            (p.second * d.maxY).toInt().coerceIn(0, d.maxY)
        )
    }

    private fun waitUntil(t: Long) {
        while (true) {
            val d = t - System.nanoTime()
            if (d <= 0) return
            if (d > 2_000_000L) LockSupport.parkNanos(d - 1_000_000L)
        }
    }

    private fun ring(fill: Int, stroke: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(fill)
        g.setStroke(dp(3), stroke)
        return g
    }

    private fun flashWarn() {
        trigger?.background = ring(Color.argb(120, 255, 90, 100), Color.rgb(255, 90, 100))
        handler.postDelayed({
            trigger?.background = ring(Color.argb(60, 40, 210, 240), Color.rgb(62, 224, 255))
        }, 700)
    }

    private fun pressStart() {
        if (firing || editMode) return
        if (Turbo.state != "ready") {
            flashWarn()
            Turbo.detect()
            return
        }
        val pt = rawPoint() ?: return
        pressed = true
        firing = true
        trigger?.alpha = 0.5f
        trigger?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val dbl = mode() == "double"
        val period = (if (dbl) gp() else iv()) * 1_000_000L
        val hold = (period / 2).coerceIn(200_000L, 30_000_000L)
        thread(name = "turbo") {
            try {
                if (dbl) {
                    val t0 = System.nanoTime()
                    Turbo.tap(pt.first, pt.second, hold)
                    waitUntil(t0 + period)
                    Turbo.tap(pt.first, pt.second, hold)
                } else {
                    var next = System.nanoTime()
                    while (pressed) {
                        Turbo.tap(pt.first, pt.second, hold)
                        next += period
                        waitUntil(next)
                    }
                }
            } catch (e: Throwable) {
                Turbo.fail("Gagal menulis: " + (e.message ?: ""))
            } finally {
                handler.post { firing = false }
            }
        }
    }

    private fun pressEnd() {
        pressed = false
        trigger?.alpha = 1f
    }

    private fun newLp(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun drag(view: View, lp: WindowManager.LayoutParams, onUp: () -> Unit): View.OnTouchListener {
        var dx = 0f
        var dy = 0f
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = lp.x - e.rawX
                    dy = lp.y - e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt()
                    lp.y = (e.rawY + dy).toInt()
                    wm?.updateViewLayout(view, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    onUp()
                    true
                }
                else -> false
            }
        }
    }

    private fun applyAppearance() {
        val a = 1f - trans() / 100f
        val t = trigger
        val tl = triggerLp
        if (t != null && tl != null) {
            tl.width = tapPx()
            tl.height = tapPx()
            tl.alpha = a
            try {
                wm?.updateViewLayout(t, tl)
            } catch (_: Exception) {
            }
        }
        val g = target
        val gl = targetLp
        if (g != null && gl != null) {
            gl.width = tgPx()
            gl.height = tgPx()
            gl.alpha = if (editMode) a else minOf(a, 0.7f)
            gl.flags = if (editMode) gl.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else gl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try {
                wm?.updateViewLayout(g, gl)
            } catch (_: Exception) {
            }
        }
    }

    private fun setEdit(e: Boolean) {
        editMode = e
        applyAppearance()
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 12f
        v.setTextColor(Color.argb(200, 255, 255, 255))
        v.setPadding(0, dp(10), 0, 0)
        return v
    }

    private fun slider(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = progress
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return sb
    }

    private fun chipBg(on: Boolean): GradientDrawable {
        val g = if (on) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, Color.rgb(62, 224, 255)))
        else GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        if (!on) g.setColor(Color.argb(55, 255, 255, 255))
        return g
    }

    private fun pill(text: String, w: Int, h: Int, fill: Int, grad: Boolean = false, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        val g = if (grad) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, Color.rgb(62, 224, 255)))
        else GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        if (!grad) g.setColor(fill)
        t.background = g
        t.layoutParams = LinearLayout.LayoutParams(w, h)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun refreshSettings() {
        val dbl = mode() == "double"
        btnRep?.background = chipBg(!dbl)
        btnDbl?.background = chipBg(dbl)
        tvIv?.text = "Kecepatan repeat   ${iv()} ms  \u2022  ${1000 / iv()}/dtk"
        tvGap?.text = "Jeda dobel tap   ${gp()} ms"
        tvIv?.alpha = if (dbl) 0.35f else 1f
        skIv?.alpha = if (dbl) 0.35f else 1f
        tvGap?.alpha = if (dbl) 1f else 0.35f
        skGap?.alpha = if (dbl) 1f else 0.35f
    }

    private val statusRun = object : Runnable {
        override fun run() {
            val ok = Turbo.state == "ready"
            if (ok) {
                statusTv?.visibility = View.GONE
            } else {
                statusTv?.visibility = View.VISIBLE
                statusTv?.text = "\u25CF Belum siap: " + (if (Turbo.info.isEmpty()) "memeriksa\u2026" else Turbo.info)
                statusTv?.setTextColor(Color.rgb(255, 200, 87))
            }
            if (panelShown) handler.postDelayed(this, 1500)
        }
    }

    private fun buildPanel() {
        val lp = newLp(dp(300), WindowManager.LayoutParams.WRAP_CONTENT)
        lp.x = prefs().getInt("px", dp(16))
        lp.y = prefs().getInt("py", dp(24))
        panelLp = lp

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(12), dp(14), dp(14))
        val root = FrameLayout(this)
        root.clipToOutline = true
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
            }
        }
        root.addView(ParticleView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "\u2725  Makro Ketuk"
        title.textSize = 16f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        title.layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).also { it.gravity = Gravity.CENTER_VERTICAL }
        title.gravity = Gravity.CENTER_VERTICAL
        title.setOnTouchListener(drag(root, lp) {
            prefs().edit().putInt("px", lp.x).putInt("py", lp.y).apply()
        })
        head.addView(title)
        val done = pill("Selesai", dp(90), dp(38), accent, true) { collapse() }
        head.addView(done)
        val close = pill("\u2715", dp(38), dp(38), Color.argb(60, 255, 255, 255)) { stopSelf() }
        val clp = LinearLayout.LayoutParams(dp(38), dp(38))
        clp.leftMargin = dp(8)
        close.layoutParams = clp
        head.addView(close)
        box.addView(head)

        val st = TextView(this)
        st.textSize = 11f
        statusTv = st
        box.addView(st)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL

        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeRow.setPadding(0, dp(10), 0, 0)
        val br = pill("Repeat", 0, dp(38), 0) {
            prefs().edit().putString("mode", "repeat").apply()
            refreshSettings()
        }
        val bd = pill("Dobel tap", 0, dp(38), 0) {
            prefs().edit().putString("mode", "double").apply()
            refreshSettings()
        }
        val lpR = LinearLayout.LayoutParams(0, dp(38), 1f)
        lpR.rightMargin = dp(6)
        br.layoutParams = lpR
        bd.layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
        btnRep = br
        btnDbl = bd
        modeRow.addView(br)
        modeRow.addView(bd)
        body.addView(modeRow)

        val a = label("")
        tvIv = a
        body.addView(a)
        val s1 = slider(100, pFromMs(iv())) { p ->
            prefs().edit().putInt("interval", msFromP(p)).apply()
            refreshSettings()
        }
        skIv = s1
        body.addView(s1)

        val b = label("")
        tvGap = b
        body.addView(b)
        val s2 = slider(100, pFromMs(gp())) { p ->
            prefs().edit().putInt("gap", msFromP(p)).apply()
            refreshSettings()
        }
        skGap = s2
        body.addView(s2)

        val l3 = label("Ukuran tombol")
        body.addView(l3)
        body.addView(slider(90, prefs().getInt("tapSize", 56) - 30) { p ->
            prefs().edit().putInt("tapSize", 30 + p).apply()
            l3.text = "Ukuran tombol   ${30 + p}"
            applyAppearance()
        })
        l3.text = "Ukuran tombol   ${prefs().getInt("tapSize", 56)}"

        val l4 = label("Ukuran target")
        body.addView(l4)
        body.addView(slider(76, prefs().getInt("tgSize", 44) - 24) { p ->
            prefs().edit().putInt("tgSize", 24 + p).apply()
            l4.text = "Ukuran target   ${24 + p}"
            applyAppearance()
        })
        l4.text = "Ukuran target   ${prefs().getInt("tgSize", 44)}"

        val l5 = label("Transparansi")
        body.addView(l5)
        body.addView(slider(85, trans()) { p ->
            prefs().edit().putInt("trans", p).apply()
            l5.text = "Transparansi   $p%"
            applyAppearance()
        })
        l5.text = "Transparansi   ${trans()}%"

        val hint = TextView(this)
        hint.text = "Geser lingkaran biru ke tempat jempol, lingkaran ungu ke tombol di game, lalu tekan Selesai."
        hint.textSize = 11f
        hint.setTextColor(Color.argb(170, 255, 255, 255))
        hint.setPadding(0, dp(12), 0, 0)
        body.addView(hint)

        val scroll = MaxHeightScroll(this) { (metrics().heightPixels * 0.7f).toInt() }
        scroll.addView(body)
        box.addView(scroll)

        panelBox = root
        refreshSettings()
    }

    private fun buildBubble() {
        val size = dp(46)
        val tv = TextView(this)
        tv.text = "\u2630"
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        tv.textSize = 18f
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.argb(235, 24, 26, 44))
        g.setStroke(dp(2), Color.argb(220, 255, 255, 255))
        tv.background = g
        val lp = newLp(size, size)
        lp.x = dockX(prefs().getBoolean("bleft", false), size)
        lp.y = prefs().getInt("by", dp(160))
        bubble = tv
        bubbleLp = lp

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var leftSide = false
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                    leftSide = (lp.x + size / 2) < metrics().widthPixels / 2
                    moved = false
                    v.alpha = 1f
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    lp.x = (ox + dx).toInt()
                    lp.y = (oy + dy).toInt()
                    wm?.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - sx
                    val inward = if (leftSide) dx else -dx
                    if (!moved || inward > dp(70)) expand() else snapBubble()
                }
                MotionEvent.ACTION_CANCEL -> snapBubble()
            }
            true
        }
    }

    private fun dockX(left: Boolean, size: Int): Int {
        val w = metrics().widthPixels
        return if (left) -(size * 0.35f).toInt() else w - (size * 0.65f).toInt()
    }

    private fun snapBubble() {
        val lp = bubbleLp ?: return
        val v = bubble ?: return
        val size = lp.width
        val m = metrics()
        val left = (lp.x + size / 2) < m.widthPixels / 2
        val tx = dockX(left, size)
        lp.y = lp.y.coerceIn(0, m.heightPixels - size)
        prefs().edit().putBoolean("bleft", left).putInt("by", lp.y).apply()
        val anim = ValueAnimator.ofInt(lp.x, tx)
        anim.duration = 180
        anim.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm?.updateViewLayout(v, lp)
            } catch (_: Exception) {
            }
        }
        anim.start()
        v.alpha = 0.6f
    }

    private fun addPanel() {
        val b = panelBox ?: return
        val lp = panelLp ?: return
        if (panelShown) return
        try {
            wm?.addView(b, lp)
            panelShown = true
            handler.post(statusRun)
        } catch (_: Exception) {
        }
    }

    private fun removePanel() {
        val b = panelBox ?: return
        if (!panelShown) return
        panelShown = false
        handler.removeCallbacks(statusRun)
        try {
            wm?.removeView(b)
        } catch (_: Exception) {
        }
    }

    private fun addBubble() {
        val b = bubble ?: return
        val lp = bubbleLp ?: return
        if (bubbleShown) return
        lp.x = dockX(prefs().getBoolean("bleft", false), lp.width)
        lp.y = prefs().getInt("by", dp(160))
        try {
            wm?.addView(b, lp)
            bubbleShown = true
            b.alpha = 0.6f
        } catch (_: Exception) {
        }
    }

    private fun removeBubble() {
        val b = bubble ?: return
        if (!bubbleShown) return
        bubbleShown = false
        try {
            wm?.removeView(b)
        } catch (_: Exception) {
        }
    }

    private fun expand() {
        removeBubble()
        addPanel()
        setEdit(true)
    }

    private fun collapse() {
        removePanel()
        addBubble()
        setEdit(false)
    }

    private fun showOverlay() {
        Turbo.detect()

        val tg = TextView(this)
        tg.background = ring(Color.argb(50, 139, 123, 255), Color.rgb(160, 145, 255))
        val tgLp = newLp(tgPx(), tgPx())
        tgLp.x = prefs().getInt("tx", dp(100))
        tgLp.y = prefs().getInt("ty", dp(360))
        tg.setOnTouchListener(drag(tg, tgLp) {
            prefs().edit().putInt("tx", tgLp.x).putInt("ty", tgLp.y).apply()
        })
        target = tg
        targetLp = tgLp
        wm?.addView(tg, tgLp)

        val tr = TextView(this)
        tr.background = ring(Color.argb(60, 40, 210, 240), Color.rgb(62, 224, 255))
        val trLp = newLp(tapPx(), tapPx())
        trLp.x = prefs().getInt("gx", dp(100))
        trLp.y = prefs().getInt("gy", dp(260))
        val dragTr = drag(tr, trLp) {
            prefs().edit().putInt("gx", trLp.x).putInt("gy", trLp.y).apply()
        }
        tr.setOnTouchListener { v, e ->
            if (editMode) {
                dragTr.onTouch(v, e)
            } else {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> pressStart()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressEnd()
                }
                true
            }
        }
        trigger = tr
        triggerLp = trLp
        wm?.addView(tr, trLp)

        buildPanel()
        buildBubble()
        expand()
    }

    private fun hideOverlay() {
        pressed = false
        firing = false
        removePanel()
        removeBubble()
        for (v in listOf<View?>(target, trigger)) {
            if (v != null) {
                try {
                    wm?.removeView(v)
                } catch (_: Exception) {
                }
            }
        }
        target = null
        trigger = null
        panelBox = null
        bubble = null
        Turbo.reset()
    }
}
