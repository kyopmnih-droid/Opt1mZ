plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cok.optimasihp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cok.optimasihp"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "3.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
}

val fetchFonts by tasks.registering {
    val outDir = File(projectDir, "src/main/assets/fonts")
    doLast {
        outDir.mkdirs()
        listOf("Regular", "Medium", "SemiBold").forEach { w ->
            val f = File(outDir, "Poppins-$w.ttf")
            if (!f.exists() || f.length() < 1000) {
                try {
                    java.net.URL("https://github.com/google/fonts/raw/main/ofl/poppins/Poppins-$w.ttf").openStream().use { i ->
                        f.outputStream().use { o -> i.copyTo(o) }
                    }
                } catch (e: Exception) {
                    f.delete()
                    println("Font $w gagal diunduh: " + e.message)
                }
            }
        }
    }
}

tasks.named("preBuild") { dependsOn(fetchFonts) }
