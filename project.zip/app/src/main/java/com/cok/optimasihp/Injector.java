package com.cok.optimasihp;

import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Injector {

    private static Object im;
    private static Method inject;
    private static Method setSource;
    private static Method setDisplayId;
    private static final int DEVICE_ID = 0;
    private static volatile int gen = 0;

    public static void main(String[] args) {
        try {
            init();
        } catch (Throwable t) {
            System.out.println("ERR init: " + t);
            System.out.flush();
            System.exit(1);
            return;
        }
        System.out.println("READY");
        System.out.flush();
        final ExecutorService ex = Executors.newSingleThreadExecutor();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = r.readLine()) != null) {
                final String[] p = line.trim().split("\\s+");
                if (p.length == 0 || p[0].isEmpty()) continue;
                if (p[0].equals("STOP")) {
                    gen++;
                    continue;
                }
                if (p[0].equals("QUIT")) break;
                final int g = gen;
                ex.submit(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            exec(p, g);
                        } catch (Throwable t) {
                            System.out.println("ERR " + t);
                            System.out.flush();
                        }
                    }
                });
            }
        } catch (Throwable ignored) {
        }
        gen++;
        ex.shutdownNow();
        System.exit(0);
    }

    private static void init() throws Exception {
        try {
            Class<?> imc = Class.forName("android.hardware.input.InputManager");
            Method gi = imc.getDeclaredMethod("getInstance");
            gi.setAccessible(true);
            im = gi.invoke(null);
            inject = imc.getMethod("injectInputEvent", InputEvent.class, int.class);
        } catch (Throwable t1) {
            Class<?> sm = Class.forName("android.os.ServiceManager");
            IBinder b = (IBinder) sm.getMethod("getService", String.class).invoke(null, "input");
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            im = stub.getMethod("asInterface", IBinder.class).invoke(null, b);
            for (Method m : im.getClass().getMethods()) {
                if (m.getName().equals("injectInputEvent")) {
                    inject = m;
                    break;
                }
            }
            if (inject == null) throw new IllegalStateException("injectInputEvent tidak ditemukan");
        }
        try {
            setSource = InputEvent.class.getMethod("setSource", int.class);
        } catch (Throwable ignored) {
        }
        try {
            setDisplayId = MotionEvent.class.getMethod("setDisplayId", int.class);
        } catch (Throwable ignored) {
        }
    }

    private static int i(String[] p, int k) {
        return Integer.parseInt(p[k]);
    }

    private static long l(String[] p, int k) {
        return Long.parseLong(p[k]);
    }

    private static void exec(String[] p, int g) throws Exception {
        String c = p[0];
        if (c.equals("TAP")) {
            tap(i(p, 1), i(p, 2), l(p, 3));
        } else if (c.equals("DBL")) {
            int x = i(p, 1), y = i(p, 2);
            long gap = l(p, 3), hold = l(p, 4);
            long t0 = System.nanoTime();
            tap(x, y, hold);
            waitUntil(t0 + gap * 1000L);
            if (gen == g) tap(x, y, hold);
        } else if (c.equals("BURST")) {
            int x = i(p, 1), y = i(p, 2), n = i(p, 3);
            long period = l(p, 4), hold = l(p, 5);
            long next = System.nanoTime();
            for (int k = 0; k < n && gen == g; k++) {
                tap(x, y, hold);
                next += period * 1000L;
                waitUntil(next);
            }
        } else if (c.equals("START")) {
            int x = i(p, 1), y = i(p, 2);
            long period = l(p, 3), hold = l(p, 4);
            long next = System.nanoTime();
            while (gen == g) {
                tap(x, y, hold);
                next += period * 1000L;
                waitUntil(next);
            }
        }
    }

    private static void waitUntil(long t) {
        while (true) {
            long d = t - System.nanoTime();
            if (d <= 0) return;
            if (d > 2000000L) {
                java.util.concurrent.locks.LockSupport.parkNanos(d - 1000000L);
            }
        }
    }

    private static void tap(int x, int y, long holdUs) throws Exception {
        long downTime = SystemClock.uptimeMillis();
        send(MotionEvent.ACTION_DOWN, x, y, downTime, downTime);
        waitUntil(System.nanoTime() + holdUs * 1000L);
        send(MotionEvent.ACTION_UP, x, y, downTime, SystemClock.uptimeMillis());
    }

    private static void send(int action, int x, int y, long downTime, long eventTime) throws Exception {
        MotionEvent e = MotionEvent.obtain(downTime, eventTime, action, (float) x, (float) y,
                1.0f, 1.0f, 0, 1.0f, 1.0f, DEVICE_ID, 0);
        try {
            if (setSource != null) setSource.invoke(e, InputDevice.SOURCE_TOUCHSCREEN);
            if (setDisplayId != null) setDisplayId.invoke(e, 0);
            Object[] a = inject.getParameterTypes().length >= 3
                    ? new Object[]{e, 0, -1} : new Object[]{e, 0};
            inject.invoke(im, a);
        } finally {
            e.recycle();
        }
    }
}
