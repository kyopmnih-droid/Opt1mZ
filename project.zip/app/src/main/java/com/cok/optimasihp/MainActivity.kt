package com.cok.optimasihp

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val shizukuPkg = "moe.shizuku.privileged.api"
    private val pkgRegex = Regex("^[a-zA-Z0-9_.]+$")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#07080f"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun maxHz(): Float {
        val d = windowManager.defaultDisplay
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: 60f
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun shell(cmd: String): Pair<Boolean, String> = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        Pair(code == 0, (out + err).trim())
    } catch (e: Throwable) {
        Pair(false, e.cause?.message ?: e.message ?: "error")
    }

    private fun cmdFor(action: String, arg: String): String? {
        when (action) {
            "trim" -> return "pm trim-caches 999G"
            "anim" -> {
                if (arg != "0" && arg != "0.5" && arg != "1") return null
                return "settings put global window_animation_scale $arg; " +
                    "settings put global transition_animation_scale $arg; " +
                    "settings put global animator_duration_scale $arg"
            }
            "dpi_get" -> return "wm density"
            "dpi_set" -> {
                val n = arg.toIntOrNull() ?: return null
                if (n < 240 || n > 700) return null
                return "wm density $n"
            }
            "dpi_reset" -> return "wm density reset"
            "hz_set" -> {
                val n = arg.toIntOrNull() ?: return null
                if (n < 60 || n > 165) return null
                return "settings put system min_refresh_rate $n.0; settings put system peak_refresh_rate $n.0"
            }
            "hz_reset" -> return "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
            "gamemode" -> {
                if (!pkgRegex.matches(arg)) return null
                return "cmd game mode performance $arg 2>&1 || cmd game set --mode performance $arg 2>&1"
            }
            "stopmany" -> {
                val list = arg.split(",").filter { it.isNotBlank() }
                if (list.isEmpty() || list.any { !pkgRegex.matches(it) || it == packageName }) return null
                return list.joinToString("; ") { "am force-stop $it" }
            }
        }
        return null
    }

    inner class Bridge {

        @JavascriptInterface
        fun getInfo(): String {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val st = StatFs(Environment.getDataDirectory().path)
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            return JSONObject().apply {
                put("model", android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + android.os.Build.MODEL)
                put("cores", Runtime.getRuntime().availableProcessors())
                put("ramTotalMb", mi.totalMem / 1048576)
                put("ramFreeMb", mi.availMem / 1048576)
                put("storageTotalGb", st.totalBytes / 1e9)
                put("storageFreeGb", st.availableBytes / 1e9)
                put("battery", if (level >= 0) level * 100 / scale else 0)
                put("charging", charging)
                put("maxHz", maxHz().toDouble())
            }.toString()
        }

        @JavascriptInterface
        @Suppress("DEPRECATION")
        fun lockHighRefresh(on: Boolean): Float {
            runOnUiThread {
                val d = windowManager.defaultDisplay
                val cur = d.mode
                val best = d.supportedModes
                    .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                    .maxByOrNull { it.refreshRate }
                val lp: WindowManager.LayoutParams = window.attributes
                lp.preferredDisplayModeId = if (on && best != null) best.modeId else 0
                window.attributes = lp
            }
            return maxHz()
        }

        @JavascriptInterface
        fun launchApp(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            runOnUiThread {
                try {
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } else {
                        val m = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                        m.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(m)
                        } catch (e: Exception) {
                            startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                } catch (_: Exception) {
                }
            }
            return i != null
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openSettings(kind: String) {
            val action = when (kind) {
                "dev" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "apps" -> Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            runOnUiThread {
                try {
                    startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        @JavascriptInterface
        fun shizukuStatus(): String {
            val installed = try {
                packageManager.getPackageInfo(shizukuPkg, 0)
                true
            } catch (e: Exception) {
                false
            }
            val running = try {
                Shizuku.pingBinder()
            } catch (e: Throwable) {
                false
            }
            val granted = running && try {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (e: Throwable) {
                false
            }
            return JSONObject()
                .put("installed", installed)
                .put("running", running)
                .put("granted", granted)
                .toString()
        }

        @JavascriptInterface
        fun shizukuRequest() {
            runOnUiThread {
                try {
                    if (Shizuku.pingBinder()) Shizuku.requestPermission(1001)
                } catch (_: Throwable) {
                }
            }
        }

        @JavascriptInterface
        fun getUserApps(): String {
            val arr = JSONArray()
            packageManager.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
                .map { Pair(it.packageName, packageManager.getApplicationLabel(it).toString()) }
                .sortedBy { it.second.lowercase() }
                .forEach { arr.put(JSONObject().put("pkg", it.first).put("name", it.second)) }
            return arr.toString()
        }


        @JavascriptInterface
        fun macroStatus(): String {
            val s = TapService.instance
            val pr = getSharedPreferences("macro", Context.MODE_PRIVATE)
            return JSONObject()
                .put("enabled", s != null)
                .put("overlay", s?.overlayOn() == true)
                .put("edit", s?.editMode == true)
                .put("interval", pr.getInt("interval", 30))
                .put("gap", pr.getInt("gap", 40))
                .put("mode", pr.getString("mode", "repeat"))
                .put("engine", pr.getString("engine", "auto"))
                .put("turbo", Turbo.state)
                .put("turboInfo", Turbo.info)
                .toString()
        }

        @JavascriptInterface
        fun macroSetInterval(v: Int) {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putInt("interval", v.coerceIn(1, 2000)).apply()
        }

        @JavascriptInterface
        fun macroSetGap(v: Int) {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putInt("gap", v.coerceIn(1, 500)).apply()
        }

        @JavascriptInterface
        fun macroSetMode(m: String) {
            val v = if (m == "double") "double" else "repeat"
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putString("mode", v).apply()
        }

        @JavascriptInterface
        fun macroSetEngine(e: String) {
            val v = if (e == "turbo" || e == "normal") e else "auto"
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putString("engine", v).apply()
        }

        @JavascriptInterface
        fun macroTurboCheck() {
            Turbo.reset()
            Turbo.detect()
        }

        @JavascriptInterface
        fun macroOverlay(on: Boolean): Boolean {
            val s = TapService.instance ?: return false
            runOnUiThread { if (on) s.showOverlay() else s.hideOverlay() }
            return true
        }

        @JavascriptInterface
        fun macroResetPos() {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit()
                .remove("tx").remove("ty").remove("gx").remove("gy").remove("px").remove("py").apply()
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        @JavascriptInterface
        fun runAction(id: Int, action: String, arg: String) {
            thread {
                val cmd = cmdFor(action, arg)
                val result: Pair<Boolean, String> = when {
                    cmd == null -> Pair(false, "Perintah tidak valid")
                    !shizukuReady() -> Pair(false, "NO_SHIZUKU")
                    else -> shell(cmd)
                }
                val js = "window.onAction($id,${result.first},${JSONObject.quote(result.second)})"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }
        }
    }
}
