package com.cok.optimasihp

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#07080f"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun maxHz(): Float {
        val d = windowManager.defaultDisplay
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: 60f
    }

    inner class Bridge {

        @JavascriptInterface
        fun getInfo(): String {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)

            val st = StatFs(Environment.getDataDirectory().path)

            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            return JSONObject().apply {
                put("model", android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + android.os.Build.MODEL)
                put("cores", Runtime.getRuntime().availableProcessors())
                put("ramTotalMb", mi.totalMem / 1048576)
                put("ramFreeMb", mi.availMem / 1048576)
                put("storageTotalGb", st.totalBytes / 1e9)
                put("storageFreeGb", st.availableBytes / 1e9)
                put("battery", if (level >= 0) level * 100 / scale else 0)
                put("charging", charging)
                put("maxHz", maxHz().toDouble())
            }.toString()
        }

        @JavascriptInterface
        @Suppress("DEPRECATION")
        fun lockHighRefresh(on: Boolean): Float {
            runOnUiThread {
                val d = windowManager.defaultDisplay
                val cur = d.mode
                val best = d.supportedModes
                    .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                    .maxByOrNull { it.refreshRate }
                val lp: WindowManager.LayoutParams = window.attributes
                lp.preferredDisplayModeId = if (on && best != null) best.modeId else 0
                window.attributes = lp
            }
            return maxHz()
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun launchApp(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            runOnUiThread {
                try {
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } else {
                        val m = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                        m.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(m)
                        } catch (e: Exception) {
                            startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                } catch (_: Exception) {
                }
            }
            return i != null
        }

        @JavascriptInterface
        fun openSettings(kind: String) {
            val action = when (kind) {
                "dev" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "apps" -> Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            runOnUiThread {
                try {
                    startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }
}
