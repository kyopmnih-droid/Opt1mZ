package com.cok.optimasihp

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val shizukuPkg = "moe.shizuku.privileged.api"
    private val pkgRegex = Regex("^[a-zA-Z0-9_.]+$")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#07080f"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.webViewClient = WebViewClient()
        setContentView(web)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun maxHz(): Float {
        val d = windowManager.defaultDisplay
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: 60f
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun shell(cmd: String): Pair<Boolean, String> = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        Pair(code == 0, (out + err).trim())
    } catch (e: Throwable) {
        Pair(false, e.cause?.message ?: e.message ?: "error")
    }

    private fun cmdFor(action: String, arg: String): String? {
        when (action) {
            "trim" -> return "pm trim-caches 999G"
            "anim" -> {
                if (arg != "0" && arg != "0.5" && arg != "1") return null
                return "settings put global window_animation_scale $arg; " +
                    "settings put global transition_animation_scale $arg; " +
                    "settings put global animator_duration_scale $arg"
            }
            "dpi_get" -> return "wm density"
            "dpi_set" -> {
                val n = arg.toIntOrNull() ?: return null
                if (n < 240 || n > 700) return null
                return "wm density $n"
            }
            "dpi_reset" -> return "wm density reset"
            "hz_set" -> {
                val n = arg.toIntOrNull() ?: return null
                if (n < 60 || n > 165) return null
                return "settings put system min_refresh_rate $n.0; settings put system peak_refresh_rate $n.0"
            }
            "hz_reset" -> return "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
            "gamemode" -> {
                if (!pkgRegex.matches(arg)) return null
                return "cmd game mode performance $arg 2>&1 || cmd game set --mode performance $arg 2>&1"
            }
            "stopmany" -> {
                val list = arg.split(",").filter { it.isNotBlank() }
                if (list.isEmpty() || list.any { !pkgRegex.matches(it) || it == packageName }) return null
                return list.joinToString("; ") { "am force-stop $it" }
            }
        }
        return null
    }

    inner class Bridge {

        @JavascriptInterface
        fun getInfo(): String {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val st = StatFs(Environment.getDataDirectory().path)
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            return JSONObject().apply {
                put("model", android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + android.os.Build.MODEL)
                put("cores", Runtime.getRuntime().availableProcessors())
                put("ramTotalMb", mi.totalMem / 1048576)
                put("ramFreeMb", mi.availMem / 1048576)
                put("storageTotalGb", st.totalBytes / 1e9)
                put("storageFreeGb", st.availableBytes / 1e9)
                put("battery", if (level >= 0) level * 100 / scale else 0)
                put("charging", charging)
                put("maxHz", maxHz().toDouble())
            }.toString()
        }

        @JavascriptInterface
        @Suppress("DEPRECATION")
        fun lockHighRefresh(on: Boolean): Float {
            runOnUiThread {
                val d = windowManager.defaultDisplay
                val cur = d.mode
                val best = d.supportedModes
                    .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                    .maxByOrNull { it.refreshRate }
                val lp: WindowManager.LayoutParams = window.attributes
                lp.preferredDisplayModeId = if (on && best != null) best.modeId else 0
                window.attributes = lp
            }
            return maxHz()
        }

        @JavascriptInterface
        fun launchApp(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            runOnUiThread {
                try {
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } else {
                        val m = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                        m.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(m)
                        } catch (e: Exception) {
                            startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                } catch (_: Exception) {
                }
            }
            return i != null
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openSettings(kind: String) {
            val action = when (kind) {
                "dev" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "apps" -> Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            runOnUiThread {
                try {
                    startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        @JavascriptInterface
        fun shizukuStatus(): String {
            val installed = try {
                packageManager.getPackageInfo(shizukuPkg, 0)
                true
            } catch (e: Exception) {
                false
            }
            val running = try {
                Shizuku.pingBinder()
            } catch (e: Throwable) {
                false
            }
            val granted = running && try {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (e: Throwable) {
                false
            }
            return JSONObject()
                .put("installed", installed)
                .put("running", running)
                .put("granted", granted)
                .toString()
        }

        @JavascriptInterface
        fun shizukuRequest() {
            runOnUiThread {
                try {
                    if (Shizuku.pingBinder()) Shizuku.requestPermission(1001)
                } catch (_: Throwable) {
                }
            }
        }

        @JavascriptInterface
        fun getUserApps(): String {
            val arr = JSONArray()
            packageManager.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
                .map { Pair(it.packageName, packageManager.getApplicationLabel(it).toString()) }
                .sortedBy { it.second.lowercase() }
                .forEach { arr.put(JSONObject().put("pkg", it.first).put("name", it.second)) }
            return arr.toString()
        }


        @JavascriptInterface
        fun macroStatus(): String {
            val pr = getSharedPreferences("macro", Context.MODE_PRIVATE)
            val m = pr.getString("mode", "burst") ?: "burst"
            return JSONObject()
                .put("perm", Settings.canDrawOverlays(this@MainActivity))
                .put("shizuku", Sh.ready())
                .put("overlay", MacroService.running)
                .put("edit", MacroService.editMode)
                .put("interval", pr.getInt("interval", 30))
                .put("gap", pr.getInt("gap", 40))
                .put("burst", pr.getInt("burst", 10))
                .put("mode", if (m == "hold" || m == "double") m else "burst")
                .put("turbo", Turbo.state)
                .put("turboInfo", Turbo.info)
                .toString()
        }

        @JavascriptInterface
        fun macroSetInterval(v: Int) {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putInt("interval", v.coerceIn(1, 500)).apply()
        }

        @JavascriptInterface
        fun macroSetGap(v: Int) {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putInt("gap", v.coerceIn(1, 500)).apply()
        }

        @JavascriptInterface
        fun macroSetBurst(v: Int) {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putInt("burst", v.coerceIn(1, 100)).apply()
        }

        @JavascriptInterface
        fun macroSetMode(m: String) {
            val v = if (m == "hold" || m == "double") m else "burst"
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putString("mode", v).apply()
        }

        @JavascriptInterface
        fun macroTurboCheck() {
            Turbo.reset()
            Turbo.detect()
        }

        @JavascriptInterface
        fun macroOverlay(on: Boolean): Int {
            if (!on) {
                runOnUiThread { stopService(Intent(this@MainActivity, MacroService::class.java)) }
                return 0
            }
            if (!Settings.canDrawOverlays(this@MainActivity)) return 1
            if (!Sh.ready()) return 2
            runOnUiThread { startForegroundService(Intent(this@MainActivity, MacroService::class.java)) }
            return 0
        }

        @JavascriptInterface
        fun macroResetPos() {
            getSharedPreferences("macro", Context.MODE_PRIVATE).edit()
                .remove("tx").remove("ty").remove("gx").remove("gy").remove("px").remove("py").remove("by").apply()
        }

        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        @JavascriptInterface
        fun turboDiag(): String {
            return JSONObject()
                .put("state", Turbo.state)
                .put("info", Turbo.info)
                .toString()
        }

        @JavascriptInterface
        fun turboTest(cx: Float, cy: Float, count: Int, ms: Int): String {
            if (!Sh.ready()) return "Shizuku belum aktif"
            if (Turbo.state != "ready") {
                Turbo.detect()
                return "Belum siap: " + (if (Turbo.info.isEmpty()) "sedang memeriksa, coba lagi" else Turbo.info)
            }
            val loc = IntArray(2)
            web.getLocationOnScreen(loc)
            val dens = resources.displayMetrics.density
            val sx = loc[0] + cx * dens
            val sy = loc[1] + cy * dens
            val period = ms.coerceIn(1, 500) * 1_000_000L
            val hold = (period / 2).coerceIn(300_000L, 30_000_000L)
            thread {
                try {
                    var next = System.nanoTime()
                    for (i in 0 until count.coerceIn(1, 200)) {
                        Turbo.tap(sx, sy, hold)
                        next += period
                        while (true) {
                            val left = next - System.nanoTime()
                            if (left <= 0) break
                            if (left > 2_000_000L) java.util.concurrent.locks.LockSupport.parkNanos(left - 1_000_000L)
                        }
                    }
                } catch (e: Throwable) {
                    Turbo.fail("Gagal mengetuk: " + (e.message ?: e.javaClass.simpleName))
                }
            }
            return "OK"
        }

        @JavascriptInterface
        fun runAction(id: Int, action: String, arg: String) {
            thread {
                val cmd = cmdFor(action, arg)
                val result: Pair<Boolean, String> = when {
                    cmd == null -> Pair(false, "Perintah tidak valid")
                    !shizukuReady() -> Pair(false, "NO_SHIZUKU")
                    else -> shell(cmd)
                }
                val js = "window.onAction($id,${result.first},${JSONObject.quote(result.second)})"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }
        }
    }
}
