package com.cok.optimasihp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.locks.LockSupport
import kotlin.concurrent.thread

class MacroService : Service() {

    companion object {
        @Volatile
        var running = false

        @Volatile
        var editMode = true
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var editBtn: TextView? = null
    private var tvIv: TextView? = null
    private var tvGap: TextView? = null
    private var btnRep: TextView? = null
    private var btnDbl: TextView? = null
    private var target: TextView? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var trigger: TextView? = null

    @Volatile
    private var pressed = false
    private var firing = false

    private fun prefs() = getSharedPreferences("macro", Context.MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun iv(): Int = prefs().getInt("interval", 30).coerceIn(1, 2000)
    private fun gp(): Int = prefs().getInt("gap", 40).coerceIn(1, 500)
    private fun mode(): String = prefs().getString("mode", "repeat") ?: "repeat"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (panel == null) showOverlay()
        running = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hideOverlay()
        running = false
        super.onDestroy()
    }

    private fun startFg() {
        val ch = "macro"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Makro", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Makro aktif")
            .setContentText("Tombol makro tampil di layar")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun rawPoint(): Pair<Int, Int>? {
        val t = target ?: return null
        val d = Turbo.dev ?: return null
        val w = wm ?: return null
        val loc = IntArray(2)
        t.getLocationOnScreen(loc)
        val cx = loc[0] + t.width / 2f
        val cy = loc[1] + t.height / 2f
        val dm = DisplayMetrics()
        val disp = w.defaultDisplay
        disp.getRealMetrics(dm)
        val nx = cx / dm.widthPixels
        val ny = cy / dm.heightPixels
        val p = when (disp.rotation) {
            1 -> Pair(ny, 1f - nx)
            2 -> Pair(1f - nx, 1f - ny)
            3 -> Pair(1f - ny, nx)
            else -> Pair(nx, ny)
        }
        return Pair(
            (p.first * d.maxX).toInt().coerceIn(0, d.maxX),
            (p.second * d.maxY).toInt().coerceIn(0, d.maxY)
        )
    }

    private fun waitUntil(t: Long) {
        while (true) {
            val d = t - System.nanoTime()
            if (d <= 0) return
            if (d > 2_000_000L) LockSupport.parkNanos(d - 1_000_000L)
        }
    }

    private fun flashWarn() {
        trigger?.text = "!"
        handler.postDelayed({ trigger?.text = "TAP" }, 800)
    }

    private fun pressStart() {
        if (firing || editMode) return
        if (Turbo.state != "ready") {
            flashWarn()
            Turbo.detect()
            return
        }
        val pt = rawPoint() ?: return
        pressed = true
        firing = true
        trigger?.alpha = 0.6f
        trigger?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val dbl = mode() == "double"
        val period = (if (dbl) gp() else iv()) * 1_000_000L
        val hold = (period / 2).coerceIn(200_000L, 8_000_000L)
        thread(name = "turbo") {
            try {
                if (dbl) {
                    val t0 = System.nanoTime()
                    Turbo.tap(pt.first, pt.second, hold)
                    waitUntil(t0 + period)
                    Turbo.tap(pt.first, pt.second, hold)
                } else {
                    var next = System.nanoTime()
                    while (pressed) {
                        Turbo.tap(pt.first, pt.second, hold)
                        next += period
                        waitUntil(next)
                    }
                }
            } catch (e: Throwable) {
                Turbo.fail("Gagal menulis: " + (e.message ?: ""))
            } finally {
                handler.post { firing = false }
            }
        }
    }

    private fun pressEnd() {
        pressed = false
        trigger?.alpha = 1f
    }

    private fun newLp(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun drag(view: View, lp: WindowManager.LayoutParams, onUp: () -> Unit): View.OnTouchListener {
        var dx = 0f
        var dy = 0f
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = lp.x - e.rawX
                    dy = lp.y - e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt()
                    lp.y = (e.rawY + dy).toInt()
                    wm?.updateViewLayout(view, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    onUp()
                    true
                }
                else -> false
            }
        }
    }

    private fun circle(label: String, fill: Int, size: Int, textSize: Float): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        tv.textSize = textSize
        tv.setTypeface(null, Typeface.BOLD)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(fill)
        bg.setStroke(dp(2), Color.WHITE)
        tv.background = bg
        tv.minWidth = size
        tv.minHeight = size
        return tv
    }

    private fun setEdit(e: Boolean) {
        editMode = e
        val t = target
        val tl = targetLp
        if (t != null && tl != null) {
            tl.flags = if (e) tl.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else tl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            tl.alpha = if (e) 0.9f else 0.5f
            try {
                wm?.updateViewLayout(t, tl)
            } catch (_: Exception) {
            }
        }
        editBtn?.text = if (e) "\u2714" else "\u270E"
    }

    private fun mkBtn(label: String, w: Int, h: Int, size: Float, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = size
        t.layoutParams = LinearLayout.LayoutParams(w, h)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun chipBg(on: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(if (on) Color.rgb(139, 123, 255) else Color.argb(60, 255, 255, 255))
        return g
    }

    private fun stepOf(v: Int): Int = if (v < 10) 1 else if (v < 50) 5 else if (v < 200) 10 else 50

    private fun setIv(v: Int) {
        prefs().edit().putInt("interval", v.coerceIn(1, 2000)).apply()
        refreshSettings()
    }

    private fun setGap(v: Int) {
        prefs().edit().putInt("gap", v.coerceIn(1, 500)).apply()
        refreshSettings()
    }

    private fun refreshSettings() {
        val m = mode()
        btnRep?.background = chipBg(m == "repeat")
        btnDbl?.background = chipBg(m == "double")
        val i = iv()
        tvIv?.text = "Interval  $i ms  (${1000 / i}/dtk)"
        tvGap?.text = "Jeda dobel  ${gp()} ms"
        tvGap?.alpha = if (m == "double") 1f else 0.4f
        tvIv?.alpha = if (m == "double") 0.4f else 1f
    }

    private fun stepRow(label: TextView, minus: () -> Unit, plus: () -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        label.textSize = 13f
        label.setTextColor(Color.WHITE)
        label.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        r.addView(label)
        r.addView(mkBtn("\u2212", dp(42), dp(42), 20f) { minus() })
        r.addView(mkBtn("+", dp(42), dp(42), 20f) { plus() })
        return r
    }

    private fun buildSettings(): LinearLayout {
        val s = LinearLayout(this)
        s.orientation = LinearLayout.VERTICAL
        s.minimumWidth = dp(260)
        s.setPadding(dp(8), dp(6), dp(8), dp(6))
        s.visibility = View.GONE

        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        val br = mkBtn("Repeat", 0, dp(38), 14f) {
            prefs().edit().putString("mode", "repeat").apply()
            refreshSettings()
        }
        val bd = mkBtn("Dobel tap", 0, dp(38), 14f) {
            prefs().edit().putString("mode", "double").apply()
            refreshSettings()
        }
        val lpR = LinearLayout.LayoutParams(0, dp(38), 1f)
        lpR.rightMargin = dp(4)
        br.layoutParams = lpR
        bd.layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
        btnRep = br
        btnDbl = bd
        modeRow.addView(br)
        modeRow.addView(bd)
        s.addView(modeRow)

        val a = TextView(this)
        tvIv = a
        s.addView(stepRow(a, { val v = iv(); setIv(v - stepOf(v - 1)) }, { val v = iv(); setIv(v + stepOf(v)) }))

        val b = TextView(this)
        tvGap = b
        s.addView(stepRow(b, { val v = gp(); setGap(v - stepOf(v - 1)) }, { val v = gp(); setGap(v + stepOf(v)) }))

        val hint = TextView(this)
        hint.text = "Repeat: ditahan terus mengetuk. Dobel tap: 2 ketukan tiap tekan."
        hint.textSize = 11f
        hint.setTextColor(Color.argb(170, 255, 255, 255))
        s.addView(hint)

        refreshSettings()
        return s
    }

    private fun showOverlay() {
        Turbo.detect()
        val size = dp(58)

        val tg = circle("+", Color.argb(170, 139, 123, 255), size, 24f)
        val tgLp = newLp(size, size)
        tgLp.x = prefs().getInt("tx", dp(100))
        tgLp.y = prefs().getInt("ty", dp(360))
        tg.setOnTouchListener(drag(tg, tgLp) {
            prefs().edit().putInt("tx", tgLp.x).putInt("ty", tgLp.y).apply()
        })
        wm?.addView(tg, tgLp)
        target = tg
        targetLp = tgLp

        val tr = circle("TAP", Color.argb(200, 20, 160, 190), size, 13f)
        val trLp = newLp(size, size)
        trLp.x = prefs().getInt("gx", dp(100))
        trLp.y = prefs().getInt("gy", dp(260))
        val dragTr = drag(tr, trLp) {
            prefs().edit().putInt("gx", trLp.x).putInt("gy", trLp.y).apply()
        }
        tr.setOnTouchListener { v, e ->
            if (editMode) {
                dragTr.onTouch(v, e)
            } else {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> pressStart()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressEnd()
                }
                true
            }
        }
        wm?.addView(tr, trLp)
        trigger = tr

        buildPanel()
        setEdit(true)
    }

    private fun buildPanel() {
        val lp = newLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        lp.x = prefs().getInt("px", dp(16))
        lp.y = prefs().getInt("py", dp(120))

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(6), dp(6), dp(6), dp(6))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(235, 20, 22, 36))
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        box.background = bg

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val handle = mkBtn("\u2725", dp(44), dp(44), 18f) {}
        handle.setOnTouchListener(drag(box, lp) {
            prefs().edit().putInt("px", lp.x).putInt("py", lp.y).apply()
        })
        val edit = mkBtn("\u2714", dp(44), dp(44), 18f) { setEdit(!editMode) }
        editBtn = edit
        val settings = buildSettings()
        val gear = mkBtn("\u2699", dp(44), dp(44), 18f) {
            settings.visibility = if (settings.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            refreshSettings()
        }
        row.addView(handle)
        row.addView(edit)
        row.addView(gear)
        row.addView(mkBtn("\u2715", dp(44), dp(44), 18f) { stopSelf() })

        box.addView(row)
        box.addView(settings)
        wm?.addView(box, lp)
        panel = box
    }

    private fun hideOverlay() {
        pressed = false
        firing = false
        for (v in listOf<View?>(target, trigger, panel)) {
            if (v != null) {
                try {
                    wm?.removeView(v)
                } catch (_: Exception) {
                }
            }
        }
        target = null
        trigger = null
        panel = null
        editBtn = null
        Turbo.reset()
    }
}
