package com.cok.optimasihp

import android.content.pm.PackageManager
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku

object Sh {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun spawn(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    fun open(cmd: String): Process? = try {
        spawn(cmd)
    } catch (e: Throwable) {
        null
    }
}

object Turbo {

    @Volatile
    var state = "unknown"

    @Volatile
    var info = ""

    @Volatile
    var apk = ""

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var detecting = false

    fun fail(msg: String) {
        state = "off"
        info = msg
        close()
    }

    fun close() {
        try {
            out?.write("QUIT\n".toByteArray())
            out?.flush()
        } catch (_: Throwable) {
        }
        try {
            out?.close()
        } catch (_: Throwable) {
        }
        try {
            proc?.destroy()
        } catch (_: Throwable) {
        }
        out = null
        proc = null
    }

    fun reset() {
        close()
        state = "unknown"
        info = ""
    }

    fun detect() {
        if (state == "ready" || detecting) return
        detecting = true
        thread(name = "inj-start") {
            try {
                if (!Sh.ready()) {
                    fail("Shizuku belum aktif")
                    return@thread
                }
                if (apk.isEmpty()) {
                    fail("Lokasi aplikasi tidak diketahui")
                    return@thread
                }
                val p = Sh.open("CLASSPATH='" + apk + "' exec app_process /system/bin com.cok.optimasihp.Injector 2>&1")
                if (p == null) {
                    fail("Tidak bisa menjalankan lewat Shizuku")
                    return@thread
                }
                proc = p
                out = p.outputStream
                val rd = p.inputStream.bufferedReader()
                val first = AtomicReference<String?>(null)
                val t = thread(name = "inj-read") {
                    try {
                        first.set(rd.readLine())
                    } catch (_: Throwable) {
                    }
                }
                t.join(7000)
                val line = first.get()
                if (line == "READY") {
                    state = "ready"
                    info = "siap"
                    thread(name = "inj-out") {
                        try {
                            while (true) {
                                val l = rd.readLine() ?: break
                                if (l.startsWith("ERR")) info = l
                            }
                        } catch (_: Throwable) {
                        }
                        if (proc === p) {
                            state = "off"
                            info = "proses ketukan berhenti"
                        }
                    }
                } else {
                    fail("Gagal memulai: " + (line ?: "tidak ada respons"))
                }
            } catch (e: Throwable) {
                fail(e.message ?: "error")
            } finally {
                detecting = false
            }
        }
    }

    @Synchronized
    fun send(cmd: String): Boolean {
        val o = out ?: return false
        return try {
            o.write((cmd + "\n").toByteArray())
            o.flush()
            true
        } catch (e: Throwable) {
            fail("Koneksi terputus")
            false
        }
    }

    fun burst(x: Int, y: Int, n: Int, periodUs: Long, holdUs: Long) = send("BURST $x $y $n $periodUs $holdUs")
    fun dbl(x: Int, y: Int, gapUs: Long, holdUs: Long) = send("DBL $x $y $gapUs $holdUs")
    fun start(x: Int, y: Int, periodUs: Long, holdUs: Long) = send("START $x $y $periodUs $holdUs")
    fun stop() = send("STOP")
}
