package com.cok.optimasihp

import android.content.pm.PackageManager
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.locks.LockSupport
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku

object Sh {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun spawn(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    fun run(cmd: String): Pair<Boolean, String> = try {
        val p = spawn(cmd)
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        Pair(p.waitFor() == 0, (out + err).trim())
    } catch (e: Throwable) {
        Pair(false, e.cause?.message ?: e.message ?: "error")
    }

    fun open(cmd: String): Process? = try {
        spawn(cmd)
    } catch (e: Throwable) {
        null
    }
}

object Turbo {

    data class Dev(
        val path: String,
        val maxX: Int,
        val maxY: Int,
        val slot: Int,
        val trackMax: Int,
        val pressure: Boolean,
        val major: Boolean
    )

    @Volatile
    var state = "unknown"

    @Volatile
    var info = ""

    @Volatile
    var dev: Dev? = null

    private var proc: Process? = null
    private var out: OutputStream? = null
    private var counter = 0
    private var detecting = false
    private val is64 = android.os.Process.is64Bit()
    private val evSize = if (is64) 24 else 16

    fun fail(msg: String) {
        state = "off"
        info = msg
        close()
    }

    fun close() {
        try {
            out?.close()
        } catch (_: Throwable) {
        }
        try {
            proc?.destroy()
        } catch (_: Throwable) {
        }
        out = null
        proc = null
    }

    fun reset() {
        close()
        dev = null
        state = "unknown"
        info = ""
    }

    private fun range(blk: String, code: String): Pair<Int, Int>? {
        val m = Regex("\\b$code\\s*:\\s*value\\s+-?\\d+,\\s*min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)").find(blk)
            ?: return null
        return Pair(m.groupValues[1].toInt(), m.groupValues[2].toInt())
    }

    fun detect() {
        if (state == "ready" || detecting) return
        detecting = true
        thread(name = "turbo-detect") {
            try {
                if (!Sh.ready()) {
                    fail("Shizuku belum aktif")
                    return@thread
                }
                val (ok, txt) = Sh.run("getevent -p")
                if (!ok || txt.isEmpty()) {
                    fail("Tidak bisa membaca perangkat input")
                    return@thread
                }
                var best: Dev? = null
                for (blk in txt.split("add device")) {
                    val path = Regex("(/dev/input/event\\d+)").find(blk)?.value ?: continue
                    val x = range(blk, "0035") ?: continue
                    val y = range(blk, "0036") ?: continue
                    val slot = range(blk, "002f") ?: continue
                    val tr = range(blk, "0039")
                    val d = Dev(
                        path, x.second, y.second, slot.second,
                        tr?.second ?: 65535,
                        range(blk, "003a") != null,
                        range(blk, "0030") != null
                    )
                    if (blk.contains("INPUT_PROP_DIRECT")) {
                        best = d
                        break
                    }
                    if (best == null) best = d
                }
                val d = best
                if (d == null) {
                    fail("Layar sentuh tidak ditemukan")
                    return@thread
                }
                val p = Sh.open("exec cat > " + d.path)
                if (p == null) {
                    fail("Tidak bisa membuka perangkat sentuh")
                    return@thread
                }
                Thread.sleep(250)
                if (!p.isAlive) {
                    val e = try {
                        p.errorStream.bufferedReader().readText().trim()
                    } catch (_: Throwable) {
                        ""
                    }
                    fail("Tidak bisa menulis ke " + d.path + " " + e.take(80))
                    return@thread
                }
                proc = p
                out = p.outputStream
                dev = d
                info = d.path
                state = "ready"
            } catch (e: Throwable) {
                fail(e.message ?: "error")
            } finally {
                detecting = false
            }
        }
    }

    private fun ev(bb: ByteBuffer, type: Int, code: Int, value: Int) {
        if (is64) {
            bb.putLong(0)
            bb.putLong(0)
        } else {
            bb.putInt(0)
            bb.putInt(0)
        }
        bb.putShort(type.toShort())
        bb.putShort(code.toShort())
        bb.putInt(value)
    }

    private fun downBytes(d: Dev, rx: Int, ry: Int, id: Int): ByteArray {
        val bb = ByteBuffer.allocate(evSize * 8).order(ByteOrder.LITTLE_ENDIAN)
        ev(bb, 3, 0x2f, d.slot)
        ev(bb, 3, 0x39, id)
        ev(bb, 3, 0x35, rx)
        ev(bb, 3, 0x36, ry)
        if (d.major) ev(bb, 3, 0x30, 6)
        if (d.pressure) ev(bb, 3, 0x3a, 60)
        ev(bb, 0, 0, 0)
        return bb.array().copyOf(bb.position())
    }

    private fun upBytes(d: Dev): ByteArray {
        val bb = ByteBuffer.allocate(evSize * 3).order(ByteOrder.LITTLE_ENDIAN)
        ev(bb, 3, 0x2f, d.slot)
        ev(bb, 3, 0x39, -1)
        ev(bb, 0, 0, 0)
        return bb.array().copyOf(bb.position())
    }

    private fun pause(ns: Long) {
        val end = System.nanoTime() + ns
        while (true) {
            val left = end - System.nanoTime()
            if (left <= 0) return
            if (left > 2_000_000L) LockSupport.parkNanos(left - 1_000_000L)
        }
    }

    @Synchronized
    fun tap(rx: Int, ry: Int, holdNs: Long) {
        val o = out ?: throw IllegalStateException("Turbo belum siap")
        val d = dev ?: throw IllegalStateException("Turbo belum siap")
        val base = (d.trackMax / 2).coerceAtLeast(1)
        val span = minOf(1000, d.trackMax - base).coerceAtLeast(1)
        val id = base + (counter++ % span)
        o.write(downBytes(d, rx, ry, id))
        o.flush()
        pause(holdNs)
        o.write(upBytes(d))
        o.flush()
    }
}
